MUSFIT WEB
Bu sürüm Mac gerektirmez. index.html dosyasını telefonda Safari ile açabilirsiniz.
Kalıcı olarak ana ekrana uygulama gibi eklemek için dosyanın HTTPS üzerinden yayınlanması gerekir.
İsterseniz sonraki adımda GitHub Pages ile ücretsiz yayınlayıp iPhone ana ekranına ekleyebiliriz.
